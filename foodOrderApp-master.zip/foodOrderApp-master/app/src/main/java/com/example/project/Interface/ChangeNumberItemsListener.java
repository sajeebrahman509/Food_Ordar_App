package com.example.project.Interface;

public interface ChangeNumberItemsListener {
    void changed();
}
